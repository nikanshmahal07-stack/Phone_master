package com.nikansh.phonemaster

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.hardware.Sensor
import android.hardware.SensorManager
import java.text.DecimalFormat
import kotlin.math.max

class MainActivity : Activity() {

    private val pageColor = Color.rgb(7, 12, 23)
    private val cardColor = Color.rgb(17, 29, 48)
    private val accent = Color.rgb(54, 169, 255)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pageColor
        window.navigationBarColor = pageColor
        window.decorView.systemUiVisibility = 0

        val scroll = ScrollView(this).apply {
            setBackgroundColor(pageColor)
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        scroll.addView(content)
        setContentView(scroll)
        renderDashboard()
    }

    private fun renderDashboard() {
        content.removeAllViews()

        addText("PHONE MASTER PRO", 27f, accent, true, 0, 4)
        addText("Device information dashboard", 14f, Color.LTGRAY, false, 0, 18)

        val refresh = Button(this).apply {
            text = "REFRESH INFORMATION"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 126, 220)))
            setOnClickListener { renderDashboard() }
        }
        content.addView(refresh, matchWrap())

        addSection("DEVICE INFORMATION", listOf(
            "Manufacturer" to Build.MANUFACTURER,
            "Brand" to Build.BRAND,
            "Model" to Build.MODEL,
            "Device" to Build.DEVICE,
            "Product" to Build.PRODUCT,
            "Hardware" to Build.HARDWARE,
            "Board" to Build.BOARD
        ))

        addSection("ANDROID SYSTEM", listOf(
            "Android version" to Build.VERSION.RELEASE,
            "SDK level" to Build.VERSION.SDK_INT.toString(),
            "Build ID" to Build.DISPLAY,
            "Security patch" to (Build.VERSION.SECURITY_PATCH ?: "Not available"),
            "Supported CPU ABI" to Build.SUPPORTED_ABIS.joinToString()
        ))

        val memory = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        memory.getMemoryInfo(memInfo)
        val totalRam = memInfo.totalMem
        val freeRam = memInfo.availMem
        val usedRam = max(0L, totalRam - freeRam)
        addSection("MEMORY (RAM)", listOf(
            "Total RAM" to formatBytes(totalRam),
            "Available RAM" to formatBytes(freeRam),
            "Used RAM (approx.)" to formatBytes(usedRam),
            "Low memory state" to if (memInfo.lowMemory) "Yes" else "No"
        ))

        val stat = StatFs(Environment.getDataDirectory().path)
        val totalStorage = stat.blockCountLong * stat.blockSizeLong
        val freeStorage = stat.availableBlocksLong * stat.blockSizeLong
        val usedStorage = totalStorage - freeStorage
        addSection("INTERNAL STORAGE", listOf(
            "Total" to formatBytes(totalStorage),
            "Used" to formatBytes(usedStorage),
            "Available" to formatBytes(freeStorage)
        ))

        addSection("BATTERY", batteryDetails())
        addSection("DISPLAY", displayDetails())
        addSection("NETWORK", networkDetails())
        addSection("PROCESSOR", listOf(
            "Available processor cores" to Runtime.getRuntime().availableProcessors().toString(),
            "Supported architectures" to Build.SUPPORTED_ABIS.joinToString()
        ))

        addSensorSection()

        addText(
            "Privacy: This app reads device information locally. It does not send your device data to a server.",
            12f, Color.LTGRAY, false, 0, 10
        )
        addText(
            "Some hardware details are restricted by Android and may not be available to ordinary apps.",
            12f, Color.rgb(160, 178, 202), false, 0, 0
        )
    }

    private fun batteryDetails(): List<Pair<String, String>> {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return listOf("Status" to "Unavailable")
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale).toString() + "%" else "Unavailable"
        val status = when (intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
            else -> "Unknown"
        }
        val health = when (intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown"
        }
        val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val temperature = if (temp >= 0) DecimalFormat("0.0").format(temp / 10.0) + " °C" else "Unavailable"
        val technology = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unavailable"
        return listOf(
            "Charge level" to percent,
            "Status" to status,
            "Health reported by system" to health,
            "Temperature" to temperature,
            "Technology" to technology
        )
    }

    private fun displayDetails(): List<Pair<String, String>> {
        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        @Suppress("DEPRECATION")
        val refreshRate = windowManager.defaultDisplay.refreshRate
        return listOf(
            "Resolution" to "${metrics.widthPixels} × ${metrics.heightPixels}",
            "Density" to "${metrics.densityDpi} dpi",
            "Scale factor" to DecimalFormat("0.0").format(metrics.density),
            "Refresh rate" to DecimalFormat("0.0").format(refreshRate) + " Hz"
        )
    }

    private fun networkDetails(): List<Pair<String, String>> {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = if (network != null) cm.getNetworkCapabilities(network) else null
        if (caps == null) return listOf("Connection" to "No active network")
        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "Bluetooth"
            else -> "Other"
        }
        return listOf(
            "Connection type" to type,
            "Internet capability" to if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) "Available / configured" else "Not detected",
            "Validated internet" to if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "Yes" else "Not confirmed"
        )
    }

    private fun addSensorSection() {
        val manager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensors = manager.getSensorList(Sensor.TYPE_ALL)
        val lines = sensors.take(18).map { sensor ->
            (sensor.name ?: "Unnamed sensor") to
                "${sensor.vendor} • version ${sensor.version}"
        }
        val extra = if (sensors.size > 18) listOf("More sensors" to "${sensors.size - 18} additional sensor(s)") else emptyList()
        addSection("SENSORS (${sensors.size})", lines + extra)
    }

    private fun addSection(title: String, rows: List<Pair<String, String>>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(cardColor, 18)
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(heading, matchWrap())
        rows.forEach { (label, value) ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(11), 0, dp(3))
            }
            val key = TextView(this).apply {
                text = label
                textSize = 12f
                setTextColor(Color.rgb(153, 174, 201))
            }
            val data = TextView(this).apply {
                text = value
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(0, dp(3), 0, 0)
            }
            line.addView(key, matchWrap())
            line.addView(data, matchWrap())
            card.addView(line, matchWrap())
            val divider = View(this).apply { setBackgroundColor(Color.rgb(38, 56, 79)) }
            card.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        }
        val params = matchWrap()
        params.bottomMargin = dp(14)
        content.addView(card, params)
    }

    private fun addText(
        value: String, size: Float, color: Int, bold: Boolean,
        top: Int, bottom: Int
    ) {
        val view = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(top), 0, dp(bottom))
        }
        content.addView(view, matchWrap())
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.rgb(34, 54, 79))
        }

    private fun formatBytes(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        val mb = bytes / (1024.0 * 1024.0)
        return if (gb >= 1) DecimalFormat("0.00").format(gb) + " GB"
        else DecimalFormat("0.0").format(mb) + " MB"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
