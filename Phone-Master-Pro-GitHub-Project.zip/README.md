# Phone Master Pro

A beginner-friendly native Android device-information app written in Kotlin.

## Features
- Device manufacturer, brand, model and hardware details
- Android version, SDK level, build ID and security patch
- Total and available RAM
- Internal shared storage usage
- Battery charge level, charging status, reported health and temperature
- Display resolution, density and refresh rate
- Active network transport and internet capability
- Available sensors list

## Build with GitHub Actions
1. Upload this project to a GitHub repository.
2. Open the **Actions** tab.
3. Select **Build Phone Master APK**.
4. Choose **Run workflow** (or push a commit to `main`).
5. Open the completed workflow run and download the `Phone-Master-Pro-debug` artifact.

## Build locally
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Notes and limitations
- This app does not require root access.
- Android restricts access to some hardware and private system information.
- RAM and storage figures are system-reported approximations/available values.
- Battery health is the health status reported by Android, not a laboratory capacity test.
- CPU clock speed, exact battery capacity, IMEI, private app data and some network identifiers are not exposed.
- Device information stays on the phone; this starter project does not upload it.
